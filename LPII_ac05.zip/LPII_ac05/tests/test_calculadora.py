import pytest
from business.models import Calculadora
from business.exceptions_erros import ValorNegativoException

c=Calculadora()

def test_soma():
    assert c.soma(-1,1)

def test_subtracao():
    assert c.subtrai(-1, 1)

def test_multiplicacao():
    assert c.multiplica(10, 2)

def test_divisao():
    with pytest.raises(ZeroDivisionError):
        c.divide(10,0)
        