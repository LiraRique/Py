class ValorNegativoException(Exception):
    pass

class ParamentroZeroException(Exception):
    pass

class OpercaoMuitoFacilException(Exception):
    pass


