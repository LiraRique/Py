from business.exceptions_erros import ValorNegativoException,OpercaoMuitoFacilException

class Calculadora():
    def soma(self, a, b):
        if(a<0 or b<0):
            raise ValorNegativoException()
        return a + b

    def subtrai(self, a, b):
        if(a<0 or b<0):
            raise ValorNegativoException()
        return a - b

    def multiplica(self, a, b):
        if (a==1 or b==1):
            raise OpercaoMuitoFacilException()
        return a * b
    
    def divide(self, a, b):
        if (a==0 or b==0):
            raise ParametroZeroException()
        return a / b