import pytest
from business.models import Calculadora
from business.exceptions_erros import ValorNegativoException,ParamentroZeroException,OpercaoMuitoFacilException


c=Calculadora()
try:
    print(c.soma(1,2))
    print(c.subtrai(1,2))
    print(c.multiplica(2,1))

except ValorNegativoException:
    print('Não é permitido valores negativos')
except ValorNegativoException:
    print('Não é permitido valores negativos')
except OpercaoMuitoFacilException:
    print('Opereção muito facil')




